BEGIN TRANSACTION;
CREATE TABLE absenderlogo (
	domain VARCHAR(253) NOT NULL, 
	inhalt BLOB, 
	typ VARCHAR(40) NOT NULL, 
	geholt_am DATETIME NOT NULL, 
	PRIMARY KEY (domain)
);
CREATE TABLE abwesenheitsantwort (
	id INTEGER NOT NULL, 
	konto_id VARCHAR(32) NOT NULL, 
	adresse VARCHAR(320) NOT NULL, 
	gesendet DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_abwesenheit_adresse UNIQUE (konto_id, adresse), 
	FOREIGN KEY(konto_id) REFERENCES konto (id) ON DELETE CASCADE
);
CREATE TABLE adressbuch (
	id VARCHAR(32) NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	name VARCHAR(120) NOT NULL, 
	farbe INTEGER NOT NULL, 
	sichtbar BOOLEAN NOT NULL, 
	reihenfolge INTEGER NOT NULL, 
	ist_lokal BOOLEAN NOT NULL, 
	art VARCHAR(16) NOT NULL, 
	herkunft VARCHAR(120) NOT NULL, 
	url TEXT NOT NULL, 
	benutzer_name VARCHAR(320) NOT NULL, 
	passwort TEXT NOT NULL, 
	oauth_zugang_id VARCHAR(32), 
	ctag VARCHAR(255) NOT NULL, 
	sync_token TEXT NOT NULL, 
	angelegt DATETIME NOT NULL, 
	zuletzt_geprueft DATETIME, 
	letzter_fehler TEXT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(benutzer_id) REFERENCES benutzer (id) ON DELETE CASCADE, 
	FOREIGN KEY(oauth_zugang_id) REFERENCES oauth_zugang (id) ON DELETE SET NULL
);
CREATE TABLE aenderung (
	seq INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	benutzer_id VARCHAR(32) NOT NULL, 
	art VARCHAR(10) NOT NULL, 
	kennung VARCHAR(40) NOT NULL, 
	konto_id VARCHAR(32) NOT NULL, 
	weg BOOLEAN NOT NULL, 
	zeit INTEGER NOT NULL
);
INSERT INTO "aenderung" VALUES(1,'9c4a45c715b3446f930971f8d95cbaff','postfach','96ab0ddd61a3483983456ed3531e8fc6','96ab0ddd61a3483983456ed3531e8fc6',0,1795545397);
INSERT INTO "aenderung" VALUES(2,'9c4a45c715b3446f930971f8d95cbaff','ordner','1','96ab0ddd61a3483983456ed3531e8fc6',0,1795545397);
CREATE TABLE anhang (
	id INTEGER NOT NULL, 
	nachricht_id INTEGER NOT NULL, 
	teil_id VARCHAR(32) NOT NULL, 
	dateiname VARCHAR(400) NOT NULL, 
	mime VARCHAR(120) NOT NULL, 
	groesse INTEGER NOT NULL, 
	cid VARCHAR(300) NOT NULL, 
	blob_hash VARCHAR(64) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(nachricht_id) REFERENCES nachricht (id) ON DELETE CASCADE
);
CREATE TABLE api_schluessel (
	id VARCHAR(32) NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	schluessel_hash VARCHAR(64) NOT NULL, 
	praefix VARCHAR(16) NOT NULL, 
	stufe VARCHAR(16) NOT NULL, 
	konten_json TEXT NOT NULL, 
	aufgaben BOOLEAN DEFAULT '0' NOT NULL, 
	schlagworte BOOLEAN DEFAULT '0' NOT NULL, 
	angelegt DATETIME NOT NULL, 
	zuletzt_benutzt DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(benutzer_id) REFERENCES benutzer (id) ON DELETE CASCADE
);
INSERT INTO "api_schluessel" VALUES('5b36ab50b6264eb9b1b7ef12de6e5bf3','9c4a45c715b3446f930971f8d95cbaff','Dashboard','ef48773d8fbdb73775a50b0b2880067ba60334213e4e4e517a57d448039cb771','nxm_bestan','anzahl','["96ab0ddd61a3483983456ed3531e8fc6"]',0,0,'2026-11-24 18:36:37.048692',NULL);
CREATE TABLE app_kopplung (
	id VARCHAR(32) NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	geheimnis_hash VARCHAR(64) NOT NULL, 
	code_hash VARCHAR(64) NOT NULL, 
	gilt_bis DATETIME NOT NULL, 
	abgeholt DATETIME, 
	geraet VARCHAR(200) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(benutzer_id) REFERENCES benutzer (id) ON DELETE CASCADE
);
CREATE TABLE aufgabe (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	konto_id VARCHAR(32) NOT NULL, 
	nachricht_id INTEGER, 
	message_id VARCHAR(500) NOT NULL, 
	betreff TEXT NOT NULL, 
	von_name VARCHAR(320) NOT NULL, 
	von_adresse VARCHAR(320) NOT NULL, 
	mail_datum DATETIME, 
	erledigt DATETIME, 
	faellig DATETIME, 
	reihenfolge INTEGER NOT NULL, 
	angelegt DATETIME NOT NULL, 
	fern_art VARCHAR(20) DEFAULT '' NOT NULL, 
	verbindung_id VARCHAR(32), 
	fern_id VARCHAR(64) DEFAULT '' NOT NULL, 
	fern_url TEXT DEFAULT '' NOT NULL, 
	fern_liste VARCHAR(200) DEFAULT '' NOT NULL, 
	fern_geloescht BOOLEAN DEFAULT '0' NOT NULL, 
	nur_gesendet BOOLEAN DEFAULT '0' NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_aufgabe_mail UNIQUE (benutzer_id, message_id)
);
CREATE TABLE aufgabenverbindung (
	id VARCHAR(32) NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	art VARCHAR(20) NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	zugang TEXT NOT NULL, 
	angelegt DATETIME NOT NULL, 
	zuletzt_abgeglichen DATETIME, 
	letzter_fehler VARCHAR(80) NOT NULL, 
	nur_senden BOOLEAN DEFAULT '0' NOT NULL, 
	mit_text BOOLEAN DEFAULT '0' NOT NULL, 
	ohne TEXT DEFAULT '[]' NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(benutzer_id) REFERENCES benutzer (id) ON DELETE CASCADE
);
CREATE TABLE ausgang (
	id VARCHAR(32) NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	konto_id VARCHAR(32) NOT NULL, 
	stand VARCHAR(16) NOT NULL, 
	an_json TEXT NOT NULL, 
	betreff TEXT NOT NULL, 
	message_id VARCHAR(500) NOT NULL, 
	versuche INTEGER NOT NULL, 
	letzter_fehler TEXT NOT NULL, 
	senden_ab DATETIME, 
	angelegt DATETIME NOT NULL, 
	gesendet DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(konto_id) REFERENCES konto (id) ON DELETE CASCADE
);
CREATE TABLE benutzer (
	id VARCHAR(32) NOT NULL, 
	nummer INTEGER, 
	benutzername VARCHAR(64) NOT NULL, 
	anzeigename VARCHAR(120) NOT NULL, 
	passwort_hash TEXT NOT NULL, 
	ist_betreiber BOOLEAN NOT NULL, 
	kontaktadresse VARCHAR(320) NOT NULL, 
	ki_erlaubt BOOLEAN NOT NULL, 
	ki_aktiv BOOLEAN NOT NULL, 
	ki_fremde_post BOOLEAN DEFAULT '0' NOT NULL, 
	ki_url VARCHAR(500) NOT NULL, 
	ki_modell VARCHAR(200) NOT NULL, 
	ki_schluessel TEXT NOT NULL, 
	totp_geheimnis TEXT NOT NULL, 
	totp_bestaetigt BOOLEAN NOT NULL, 
	totp_letzter_schritt INTEGER NOT NULL, 
	aufraeumen_papierkorb_tage INTEGER NOT NULL, 
	aufraeumen_junk_tage INTEGER NOT NULL, 
	aufraeumen_zuletzt DATETIME, 
	bilder_immer_laden BOOLEAN NOT NULL, 
	absenderlogos_laden BOOLEAN NOT NULL, 
	aufgaben_standard VARCHAR(200) DEFAULT '' NOT NULL, 
	aufgaben_eigene BOOLEAN DEFAULT '1' NOT NULL, 
	push_termine BOOLEAN NOT NULL, 
	push_mail BOOLEAN NOT NULL, 
	push_mail_alle_ordner BOOLEAN NOT NULL, 
	wasneu_gesehen VARCHAR(32) NOT NULL, 
	push_mail_nur_ungelesen BOOLEAN NOT NULL, 
	push_mail_buendeln BOOLEAN NOT NULL, 
	push_ruhezeit BOOLEAN NOT NULL, 
	push_ruhezeit_von VARCHAR(5) NOT NULL, 
	push_ruhezeit_bis VARCHAR(5) NOT NULL, 
	profilbild BLOB, 
	profilbild_am DATETIME, 
	gruppen_reihenfolge TEXT NOT NULL, 
	kalender_vorwahl TEXT DEFAULT '' NOT NULL, 
	angelegt DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
INSERT INTO "benutzer" VALUES('f6c001bcad3945e7b1285cf800188d07',1,'betreiber','Betrieb Beispiel','$argon2id$v=19$m=19456,t=2,p=1$WDx3znvpQsvYJ2NfRd+DGA$cAfw0cc/h1hsDPKXEwJdNjMVYKqKAd43d3vzGT/GyEo',1,'betrieb@example.com',1,0,0,'','','','v1:DwUKzF+aLqvAqe67cOsaHALTFv/JVD/6alzDODIWeh+I5KdHbi7CS7c/+L0Rb5lWPmzbcneePWbrwRy3',1,59851513,0,0,NULL,0,0,'',1,1,1,0,'0.33.0',1,1,0,'22:00','07:00',NULL,NULL,'','','2026-11-24 18:36:36.396988');
INSERT INTO "benutzer" VALUES('70eda15f445a4b40be72bf522a93bdf8',2,'Erika.Muster','Erika Muster','$argon2id$v=19$m=19456,t=2,p=1$GcpVkny6Dd7YtiBz3cD/gw$tnbgPPepOrJ52PTscu2nMpUflIaAvO7UP66b1bACiFU',0,'',1,0,0,'','','','',0,0,0,0,NULL,0,0,'',1,1,1,0,'0.33.0',1,1,0,'22:00','07:00',NULL,NULL,'','','2026-11-24 18:36:36.940351');
INSERT INTO "benutzer" VALUES('9c4a45c715b3446f930971f8d95cbaff',3,'jonas','Jonas Beispiel','$argon2id$v=19$m=19456,t=2,p=1$/NdK5DHQ8JWAqqqB44JDpA$l4sxq6+pdhtz/kR3FfqFqb5zLfyIRDyii6X/QJe5SbE',0,'jonas@example.net',1,0,0,'','','','',0,0,0,0,NULL,0,0,'',1,1,1,0,'0.33.0',1,1,0,'22:00','07:00',NULL,NULL,'','','2026-11-24 18:36:37.003561');
INSERT INTO "benutzer" VALUES('08117369979d471896039c180792284c',4,'kim','Kim Beispiel','$argon2id$v=19$m=19456,t=2,p=1$7OLIf26bDFfzu2vxNcLoVg$X+7/tTUpRND0PDfw/oXnRwVtH8CRPf2j5fVGKuBs880',0,'familie@example.net',1,0,0,'','','','',0,0,0,0,NULL,0,0,'',1,1,1,0,'0.33.0',1,1,0,'22:00','07:00',NULL,NULL,'','','2026-11-24 18:36:37.093057');
INSERT INTO "benutzer" VALUES('08fd93116b61454da46e260b2f7fd282',5,'lou','lou','$argon2id$v=19$m=19456,t=2,p=1$8t60EcnUAGQeJfXM06CFRg$TfelnJOm5bbRlp25HvXh4hYhZNyGXCril1rtNyx7pVU',0,'Familie@Example.net',1,0,0,'','','','',0,0,0,0,NULL,0,0,'',1,1,1,0,'0.33.0',1,1,0,'22:00','07:00',NULL,NULL,'','','2026-11-24 18:36:37.140193');
INSERT INTO "benutzer" VALUES('45d21030b30a47ee86ad4aca68431984',6,'mona','Mona Beispiel','$argon2id$v=19$m=19456,t=2,p=1$N0LRjBMDzJcn5LzBQ4T/nA$pY2aQnofpz332MzCGylQ1AyUL+KeKcZ0EnVtmMWVnx8',0,'mona@example.com',1,0,0,'','','','v1:gyaWJS1DI5/FJv411ApkSsXyieSGx4MyZ6or+Etcy6sdhYXHj3iXGxTNZ1uHPbAYU6UO9W9Tb0Uw5cmN',1,59851513,0,0,NULL,0,0,'',1,1,1,0,'0.33.0',1,1,0,'22:00','07:00',NULL,NULL,'','','2026-11-24 18:36:37.185060');
INSERT INTO "benutzer" VALUES('460f83c8cb6445b48305798306d0a892',7,'sam','Sam Beispiel','$argon2id$v=19$m=19456,t=2,p=1$1X0XA/yjAmN6luHD/rQ3xA$dgUnZwMgxtyr0LyryxOXcUlxSOTm8hQF63IlaOM9YJw',0,'sam@example.com',1,0,0,'','','','',0,0,0,0,NULL,0,0,'',1,1,1,0,'0.33.0',1,1,0,'22:00','07:00',NULL,NULL,'','','2026-11-24 18:36:37.264447');
INSERT INTO "benutzer" VALUES('d08cae399db04601aa682ea2ea9f7c1a',8,'Robin.SSO','Robin Beispiel','',0,'robin@example.com',1,0,0,'','','','',0,0,0,0,NULL,0,0,'',1,1,1,0,'0.33.0',1,1,0,'22:00','07:00',NULL,NULL,'','','2026-11-24 18:36:37.572889');
INSERT INTO "benutzer" VALUES('0bd719f4c4dc4a0dbc0364dc77d62aab',9,'j','jay','',0,'jay@example.org',1,0,0,'','','','',0,0,0,0,NULL,0,0,'',1,1,1,0,'0.33.0',1,1,0,'22:00','07:00',NULL,NULL,'','','2026-11-24 18:36:37.683076');
CREATE TABLE bildfreigabe (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	adresse VARCHAR(320) NOT NULL, 
	angelegt DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_bildfreigabe_adresse UNIQUE (benutzer_id, adresse)
);
CREATE TABLE einladung (
	id VARCHAR(32) NOT NULL, 
	schluessel_hash VARCHAR(128) NOT NULL, 
	benutzername VARCHAR(64) NOT NULL, 
	anzeigename VARCHAR(120) NOT NULL, 
	adresse VARCHAR(320) NOT NULL, 
	angelegt DATETIME NOT NULL, 
	laeuft_ab DATETIME NOT NULL, 
	eingeloest DATETIME, 
	PRIMARY KEY (id)
);
INSERT INTO "einladung" VALUES('c8f722f639ce480da073cec25ff5f4f0','bd96c21f3e346e34c6aea8afb21ad5d8a5ada01f11d69c4d8a9561d4b612738c','Erika.Muster','Erika Muster','erika@example.org','2026-11-24 18:36:36.902058','2026-12-01 18:36:36.901385','2026-11-24 18:36:36.941294');
INSERT INTO "einladung" VALUES('952f0e856e7f42d48dfee4764643667a','1e0d35c6affa42021cc72de17ffdd49b560920112b2454964d2f05c174ccd7b3','jonas','Jonas Beispiel','jonas@example.net','2026-11-24 18:36:36.968055','2026-12-01 18:36:36.967803','2026-11-24 18:36:37.004327');
INSERT INTO "einladung" VALUES('d87fc0f5d7a84dccae98953c9566cd2b','0f054bfe48872dc9149426abfe8d97ca1aab91e88d90cad45d85728b994739f0','kim','Kim Beispiel','familie@example.net','2026-11-24 18:36:37.055103','2026-12-01 18:36:37.054865','2026-11-24 18:36:37.094021');
INSERT INTO "einladung" VALUES('01d579682d6a4862bba0af1ea505e6c6','ede53cdf301ca2a5b42af1fb622bbfb80583d04182f86b2601b378e95386bf07','lou','lou','Familie@Example.net','2026-11-24 18:36:37.101942','2026-12-01 18:36:37.101735','2026-11-24 18:36:37.141345');
INSERT INTO "einladung" VALUES('c04f857c431e4fa4999f6088acff6cbc','991848c17fd647a8554018bc1773de2a0aeb0a6ee8c65459bc6d0f016247cc8c','mona','Mona Beispiel','mona@example.com','2026-11-24 18:36:37.148242','2026-12-01 18:36:37.148042','2026-11-24 18:36:37.187066');
INSERT INTO "einladung" VALUES('cb9346db048947bf9da76ee97eb16b11','97cf880e67da919c22d5a4653747a93a8f294c26b4a419e78dc2da5537453dcc','sam','Sam Beispiel','sam@example.com','2026-11-24 18:36:37.227896','2026-12-01 18:36:37.227664','2026-11-24 18:36:37.265153');
INSERT INTO "einladung" VALUES('47ce6d266ef54747b2167ea82a9e3f55','89312253cad1a9cdbfe0a5e39eaeaebfbe32edd7f6fe226fdf0381756b0ef766','robin','Robin Beispiel','robin@example.com','2026-11-24 18:36:37.432940','2026-12-01 18:36:37.432648','2026-11-24 18:36:37.567361');
INSERT INTO "einladung" VALUES('3523c748cd8f4a98a59a4836e156a359','dcf5a7970dbc168deba0fc9acf787d03ef6faf79524d188c0e0a12b8c121c113','jay','jay','jay@example.org','2026-11-24 18:36:37.592110','2026-12-01 18:36:37.591802','2026-11-24 18:36:37.680299');
INSERT INTO "einladung" VALUES('440e2aeab79e43869a885f48560d9e8a','1230de2e6b40b950a4a8c542253c38994e5dd07e252180e5257e8f07369d4030','neu.gast','Gast Beispiel','gast@example.org','2026-11-24 18:36:37.701802','2026-12-01 18:36:37.701325',NULL);
CREATE TABLE einstellung (
	schluessel VARCHAR(64) NOT NULL, 
	wert TEXT NOT NULL, 
	PRIMARY KEY (schluessel)
);
INSERT INTO "einstellung" VALUES('suche_index','fts5:betreff,von_name,von_adresse,anreisser,koerper_text');
INSERT INTO "einstellung" VALUES('oeffentliche_adresse','https://mail.example.com');
INSERT INTO "einstellung" VALUES('app_geraete_erlaubt','1');
INSERT INTO "einstellung" VALUES('api_schluessel_erlaubt','1');
CREATE TABLE erinnerungszustellung (
	id INTEGER NOT NULL, 
	termin_id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	vorkommen DATETIME NOT NULL, 
	kanal VARCHAR(20) NOT NULL, 
	zugestellt DATETIME NOT NULL, 
	schlummert_bis DATETIME, 
	erledigt BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_erinnerung UNIQUE (termin_id, vorkommen, kanal), 
	FOREIGN KEY(termin_id) REFERENCES termin (id) ON DELETE CASCADE
);
CREATE TABLE geheimnis (
	schluessel VARCHAR(64) NOT NULL, 
	wert TEXT NOT NULL, 
	PRIMARY KEY (schluessel)
);
INSERT INTO "geheimnis" VALUES('dek','v1:qhfeYY/LUvCe3lxm1QmkFUzGNz7T7Nyd+DpTbF4r4KbhksPGA9iTV19qNcmjUwiXwZFvTYTyiz928nii');
CREATE TABLE kalender (
	id VARCHAR(32) NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	name VARCHAR(120) NOT NULL, 
	farbe INTEGER NOT NULL, 
	sichtbar BOOLEAN NOT NULL, 
	reihenfolge INTEGER NOT NULL, 
	art VARCHAR(16) NOT NULL, 
	herkunft VARCHAR(120) NOT NULL, 
	url TEXT NOT NULL, 
	benutzer_name VARCHAR(320) NOT NULL, 
	passwort TEXT NOT NULL, 
	oauth_zugang_id VARCHAR(32), 
	ctag VARCHAR(255) NOT NULL, 
	sync_token TEXT NOT NULL, 
	angelegt DATETIME NOT NULL, 
	zuletzt_geprueft DATETIME, 
	letzter_fehler TEXT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(benutzer_id) REFERENCES benutzer (id) ON DELETE CASCADE, 
	FOREIGN KEY(oauth_zugang_id) REFERENCES oauth_zugang (id) ON DELETE SET NULL
);
CREATE TABLE ki_vorgang (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	zeitpunkt DATETIME NOT NULL, 
	modell VARCHAR(200) NOT NULL, 
	auftrag VARCHAR(40) NOT NULL, 
	ziel VARCHAR(40) NOT NULL, 
	rumpf TEXT NOT NULL, 
	rein INTEGER NOT NULL, 
	raus INTEGER NOT NULL, 
	fehler VARCHAR(60) NOT NULL, 
	fehler_werte TEXT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(benutzer_id) REFERENCES benutzer (id) ON DELETE CASCADE
);
CREATE TABLE kontakt (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	name VARCHAR(320) NOT NULL, 
	vorname VARCHAR(160) NOT NULL, 
	nachname VARCHAR(160) NOT NULL, 
	spitzname VARCHAR(160) NOT NULL, 
	adresse VARCHAR(320) NOT NULL, 
	firma VARCHAR(320) NOT NULL, 
	abteilung VARCHAR(160) NOT NULL, 
	titel VARCHAR(160) NOT NULL, 
	telefon VARCHAR(120) NOT NULL, 
	geburtstag VARCHAR(32) NOT NULL, 
	webseite VARCHAR(320) NOT NULL, 
	notiz TEXT NOT NULL, 
	nummern TEXT NOT NULL, 
	adressen TEXT NOT NULL, 
	anschriften TEXT NOT NULL, 
	adressbuch_id VARCHAR(32), 
	uid VARCHAR(255) NOT NULL, 
	href TEXT NOT NULL, 
	etag VARCHAR(255) NOT NULL, 
	roh TEXT NOT NULL, 
	schmutzig BOOLEAN NOT NULL, 
	quelle VARCHAR(16) NOT NULL, 
	verwendet INTEGER NOT NULL, 
	angelegt DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(adressbuch_id) REFERENCES adressbuch (id) ON DELETE CASCADE
);
CREATE TABLE kontaktgruppe (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	angelegt DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_kontaktgruppe_name UNIQUE (benutzer_id, name)
);
CREATE TABLE kontaktgruppe_mitglied (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	gruppe_id INTEGER NOT NULL, 
	kontakt_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_gruppe_mitglied UNIQUE (gruppe_id, kontakt_id)
);
CREATE TABLE konto (
	id VARCHAR(32) NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	anzeigename VARCHAR(120) NOT NULL, 
	stoerung VARCHAR(20) NOT NULL, 
	absendername VARCHAR(120) NOT NULL, 
	adresse VARCHAR(320) NOT NULL, 
	abwesenheit_aktiv BOOLEAN NOT NULL, 
	abwesenheit_von VARCHAR(10) NOT NULL, 
	abwesenheit_bis VARCHAR(10) NOT NULL, 
	abwesenheit_betreff VARCHAR(300) NOT NULL, 
	abwesenheit_text TEXT NOT NULL, 
	imap_server VARCHAR(255) NOT NULL, 
	imap_port INTEGER NOT NULL, 
	imap_sicherheit VARCHAR(16) NOT NULL, 
	imap_benutzer VARCHAR(320) NOT NULL, 
	imap_passwort TEXT NOT NULL, 
	smtp_server VARCHAR(255) NOT NULL, 
	smtp_port INTEGER NOT NULL, 
	smtp_sicherheit VARCHAR(16) NOT NULL, 
	smtp_benutzer VARCHAR(320) NOT NULL, 
	smtp_passwort TEXT NOT NULL, 
	oauth_zugang_id VARCHAR(32), 
	tags VARCHAR(255) NOT NULL, 
	aliase TEXT NOT NULL, 
	farbe INTEGER NOT NULL, 
	farbton VARCHAR(10) DEFAULT '' NOT NULL, 
	symbol VARCHAR(40) DEFAULT '' NOT NULL, 
	reihenfolge INTEGER NOT NULL, 
	aktiv BOOLEAN NOT NULL, 
	angelegt DATETIME NOT NULL, 
	zuletzt_geprueft DATETIME, 
	letzter_fehler TEXT NOT NULL, 
	letzter_fehler_art VARCHAR(30) NOT NULL, 
	erstabgleich_durch BOOLEAN NOT NULL, 
	namensraum VARCHAR(100) DEFAULT '' NOT NULL, 
	idle_aktiv BOOLEAN DEFAULT '0' NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(benutzer_id) REFERENCES benutzer (id) ON DELETE CASCADE, 
	FOREIGN KEY(oauth_zugang_id) REFERENCES oauth_zugang (id) ON DELETE SET NULL
);
INSERT INTO "konto" VALUES('96ab0ddd61a3483983456ed3531e8fc6','9c4a45c715b3446f930971f8d95cbaff','Privat','','','jonas.post@example.net',0,'','','','','imap.example.net',993,'ssl','jonas.post','v1:xSOC96VV8l5q+VUQasO81RJcAbYxjZeLFlrsiloxUG1cgzc98KXPUxLrWxt9A5c=','smtp.example.net',587,'starttls','jonas.post@example.net','v1:3vx4vOob5PLusmSnLWWTg1snW0prVwkgrx9JVQ1HPfCDcD2MtJSHgToG/AgtFvU=',NULL,'','[]',1,'','',1,1,'2026-11-24 18:36:37.024285','2026-11-24 18:36:37.026975','','',0,'',0);
CREATE TABLE mail_termin (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	message_id TEXT NOT NULL, 
	kalender VARCHAR(64) NOT NULL, 
	titel TEXT NOT NULL, 
	beginn DATETIME NOT NULL, 
	ganztaegig BOOLEAN NOT NULL, 
	link TEXT NOT NULL, 
	anfrage VARCHAR(40) NOT NULL, 
	angelegt DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(benutzer_id) REFERENCES benutzer (id) ON DELETE CASCADE
);
CREATE TABLE nachricht (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	konto_id VARCHAR(32) NOT NULL, 
	ordner_id INTEGER NOT NULL, 
	uid INTEGER NOT NULL, 
	message_id VARCHAR(500) NOT NULL, 
	thread_key VARCHAR(500) NOT NULL, 
	referenzen TEXT NOT NULL, 
	betreff_kern VARCHAR(500) NOT NULL, 
	von_name VARCHAR(320) NOT NULL, 
	von_adresse VARCHAR(320) NOT NULL, 
	an_json TEXT NOT NULL, 
	kopie_json TEXT NOT NULL, 
	betreff TEXT NOT NULL, 
	datum DATETIME NOT NULL, 
	angekommen DATETIME, 
	groesse INTEGER NOT NULL, 
	gelesen BOOLEAN NOT NULL, 
	markiert BOOLEAN NOT NULL, 
	beantwortet BOOLEAN NOT NULL, 
	schlagworte TEXT NOT NULL, 
	hat_anhang BOOLEAN NOT NULL, 
	hat_kalender BOOLEAN NOT NULL, 
	wichtigkeit VARCHAR(10) NOT NULL, 
	pruefer VARCHAR(255) NOT NULL, 
	dmarc_bestanden BOOLEAN NOT NULL, 
	abbestellen TEXT DEFAULT '' NOT NULL, 
	abbestellt_am DATETIME, 
	anreisser TEXT NOT NULL, 
	koerper_text TEXT NOT NULL, 
	koerper_html TEXT NOT NULL, 
	geblockte_bilder INTEGER NOT NULL, 
	koerper_geholt DATETIME, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_nachricht_uid UNIQUE (ordner_id, uid), 
	FOREIGN KEY(konto_id) REFERENCES konto (id) ON DELETE CASCADE, 
	FOREIGN KEY(ordner_id) REFERENCES ordner (id) ON DELETE CASCADE
);
CREATE TABLE nextime_verbindung (
	id VARCHAR(32) NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	zugang TEXT NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	version VARCHAR(40) NOT NULL, 
	zeitzone VARCHAR(64) NOT NULL, 
	sichtbar TEXT NOT NULL, 
	ohne TEXT DEFAULT '[]' NOT NULL, 
	angelegt DATETIME NOT NULL, 
	letzter_fehler VARCHAR(80) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (benutzer_id), 
	FOREIGN KEY(benutzer_id) REFERENCES benutzer (id) ON DELETE CASCADE
);
CREATE TABLE oauth_anbieter (
	id VARCHAR(32) NOT NULL, 
	art VARCHAR(20) NOT NULL, 
	client_id VARCHAR(300) NOT NULL, 
	client_secret TEXT NOT NULL, 
	mandant VARCHAR(120) NOT NULL, 
	angelegt DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE oauth_zugang (
	id VARCHAR(32) NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	art VARCHAR(20) NOT NULL, 
	adresse VARCHAR(320) NOT NULL, 
	refresh TEXT NOT NULL, 
	zugriff TEXT NOT NULL, 
	ablauf DATETIME, 
	bereich TEXT NOT NULL, 
	angelegt DATETIME NOT NULL, 
	letzter_fehler TEXT NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_oauth_zugang UNIQUE (benutzer_id, art, adresse), 
	FOREIGN KEY(benutzer_id) REFERENCES benutzer (id) ON DELETE CASCADE
);
CREATE TABLE oidc_anbieter (
	id VARCHAR(32) NOT NULL, 
	nummer INTEGER, 
	kuerzel VARCHAR(40) NOT NULL, 
	anzeigename VARCHAR(120) NOT NULL, 
	issuer VARCHAR(500) NOT NULL, 
	client_id VARCHAR(300) NOT NULL, 
	client_secret TEXT NOT NULL, 
	client_secret_enc TEXT DEFAULT '' NOT NULL, 
	scopes VARCHAR(500) NOT NULL, 
	aktiv BOOLEAN NOT NULL, 
	eingeschaltet BOOLEAN, 
	auto_create BOOLEAN DEFAULT '0' NOT NULL, 
	trusts_second_factor BOOLEAN DEFAULT '1' NOT NULL, 
	managed VARCHAR(20) DEFAULT '' NOT NULL, 
	position INTEGER DEFAULT '0' NOT NULL, 
	redirect_path VARCHAR(300), 
	registered_redirect VARCHAR(500) DEFAULT '' NOT NULL, 
	angelegt DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
INSERT INTO "oidc_anbieter" VALUES('b82deee37d57406da1899acc5f617539',1,'sso','SSO','https://sso.example.com','nexmail-bestand','v1:q18KIb024Z3ONSUllMxMQB7Gff2YAAOaN/gGwrOoNSh110aoC1XnV2Rw','v1:1Dd8FYI4IEWSttnB5wUC6wfAfCz45fpChKV0UpLUItUdQjPbK1B+oJyc','openid profile email',1,1,0,1,'',0,'','','2026-11-24 18:36:36.891713');
CREATE TABLE oidc_verknuepfung (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	anbieter_id VARCHAR(32), 
	issuer VARCHAR(255) NOT NULL, 
	subject VARCHAR(255) NOT NULL, 
	adresse_bestaetigt BOOLEAN DEFAULT '0' NOT NULL, 
	email VARCHAR(300) DEFAULT '' NOT NULL, 
	angelegt DATETIME NOT NULL, 
	zuletzt_benutzt DATETIME, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_oidc_identitaet UNIQUE (issuer, subject), 
	FOREIGN KEY(benutzer_id) REFERENCES benutzer (id) ON DELETE CASCADE, 
	FOREIGN KEY(anbieter_id) REFERENCES oidc_anbieter (id) ON DELETE CASCADE
);
INSERT INTO "oidc_verknuepfung" VALUES(1,'460f83c8cb6445b48305798306d0a892','b82deee37d57406da1899acc5f617539','https://sso.example.com','bestand-sam',0,'sam@example.com','2026-11-24 18:36:37.424560','2026-11-24 18:36:37.424563');
INSERT INTO "oidc_verknuepfung" VALUES(2,'d08cae399db04601aa682ea2ea9f7c1a','b82deee37d57406da1899acc5f617539','https://sso.example.com','bestand-robin',0,'robin@sso.example.com','2026-11-24 18:36:37.575550','2026-11-24 18:36:37.575553');
INSERT INTO "oidc_verknuepfung" VALUES(3,'0bd719f4c4dc4a0dbc0364dc77d62aab','b82deee37d57406da1899acc5f617539','https://sso.example.com','bestand-j',0,'j@sso.example.com','2026-11-24 18:36:37.684613','2026-11-24 18:36:37.684614');
CREATE TABLE ordner (
	id INTEGER NOT NULL, 
	konto_id VARCHAR(32) NOT NULL, 
	pfad VARCHAR(512) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	rolle VARCHAR(16) NOT NULL, 
	rolle_erkannt VARCHAR(16) NOT NULL, 
	rolle_von_hand VARCHAR(16) NOT NULL, 
	abonniert BOOLEAN NOT NULL, 
	waehlbar BOOLEAN NOT NULL, 
	uidvalidity INTEGER NOT NULL, 
	hoechste_uid INTEGER NOT NULL, 
	anzahl INTEGER NOT NULL, 
	ungelesen INTEGER NOT NULL, 
	wichtigkeit_nachgezogen BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_ordner_pfad UNIQUE (konto_id, pfad), 
	FOREIGN KEY(konto_id) REFERENCES konto (id) ON DELETE CASCADE
);
INSERT INTO "ordner" VALUES(1,'96ab0ddd61a3483983456ed3531e8fc6','INBOX','INBOX','posteingang','posteingang','',1,1,0,0,0,0,0);
CREATE TABLE push_anmeldung (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	endpunkt TEXT NOT NULL, 
	p256dh VARCHAR(200) NOT NULL, 
	auth VARCHAR(64) NOT NULL, 
	geraet VARCHAR(120) NOT NULL, 
	angelegt DATETIME NOT NULL, 
	zuletzt_erreicht DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(benutzer_id) REFERENCES benutzer (id) ON DELETE CASCADE, 
	UNIQUE (endpunkt)
);
CREATE TABLE regel (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	konto_id VARCHAR(32) NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	aktiv BOOLEAN NOT NULL, 
	reihenfolge INTEGER NOT NULL, 
	verknuepfung VARCHAR(8) NOT NULL, 
	bedingungen_json TEXT NOT NULL, 
	aktionen_json TEXT NOT NULL, 
	stopp BOOLEAN NOT NULL, 
	angelegt DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE ruecksetzung (
	id VARCHAR(32) NOT NULL, 
	schluessel_hash VARCHAR(128) NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	angelegt DATETIME NOT NULL, 
	laeuft_ab DATETIME NOT NULL, 
	eingeloest DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(benutzer_id) REFERENCES benutzer (id) ON DELETE CASCADE
);
CREATE TABLE schlagwort (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	atom VARCHAR(100) NOT NULL, 
	farbe INTEGER NOT NULL, 
	angelegt DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_schlagwort_atom UNIQUE (benutzer_id, atom)
);
CREATE TABLE signatur (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	konto_id VARCHAR(32) NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	html TEXT NOT NULL, 
	standard BOOLEAN NOT NULL, 
	angelegt DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE sitzung (
	id VARCHAR(32) NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	bestaetigt BOOLEAN NOT NULL, 
	geraet VARCHAR(200) NOT NULL, 
	adresse VARCHAR(64) NOT NULL, 
	art VARCHAR(10) DEFAULT 'browser' NOT NULL, 
	push_ticket VARCHAR(1024) DEFAULT '' NOT NULL, 
	push_schluessel VARCHAR(64) DEFAULT '' NOT NULL, 
	angelegt DATETIME NOT NULL, 
	zuletzt_gesehen DATETIME NOT NULL, 
	gueltig_bis DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(benutzer_id) REFERENCES benutzer (id) ON DELETE CASCADE
);
INSERT INTO "sitzung" VALUES('ec0d5bef67c74434b3444ccea1694f30','f6c001bcad3945e7b1285cf800188d07','b90f1ee4d105d5f8e0d38350124e623475f7135133615cfd5103f63f0a7c5886',1,'testclient','','browser','','','2026-11-24 18:36:36.399535','2026-11-24 18:36:36.399537','2026-12-24 18:36:36.398500');
INSERT INTO "sitzung" VALUES('78d37f11d945417da5defe0c23298aca','70eda15f445a4b40be72bf522a93bdf8','228bcfdf7423d136249b74af9cc9bda45b50001e350c65c85eafb48456e6bf2f',1,'testclient','','browser','','','2026-11-24 18:36:36.943906','2026-11-24 18:36:36.943908','2026-12-24 18:36:36.943466');
INSERT INTO "sitzung" VALUES('5ff14b3a59ad4cda84c83de2f0cf1688','9c4a45c715b3446f930971f8d95cbaff','dfce8010b3708937b6fe560225974596fbfef18ff56fb45fa5ef1df65993f60c',1,'testclient','','browser','','','2026-11-24 18:36:37.006602','2026-11-24 18:36:37.006621','2026-12-24 18:36:37.005803');
INSERT INTO "sitzung" VALUES('cc96f9a647b845d3831243dc3afb21c2','08117369979d471896039c180792284c','772d968f8c4b6853ba27c40421360ce7a10b90df678d7d35b24b4e6168b3d290',1,'testclient','','browser','','','2026-11-24 18:36:37.096203','2026-11-24 18:36:37.096211','2026-12-24 18:36:37.095344');
INSERT INTO "sitzung" VALUES('d1edb51fc00544d388c310c4cdf13159','08fd93116b61454da46e260b2f7fd282','08c791eb205b15bd9e4d3eff760f77236588bc09e2a65741fe9ae3ab2e38000e',1,'testclient','','browser','','','2026-11-24 18:36:37.143597','2026-11-24 18:36:37.143599','2026-12-24 18:36:37.143183');
INSERT INTO "sitzung" VALUES('8a3cefcf417f45728ea9c2996af5c8f0','45d21030b30a47ee86ad4aca68431984','3cd8278798b15f70ea254d11f32f06172856e4c7514d63a214c67c51ee5bddac',1,'testclient','','browser','','','2026-11-24 18:36:37.188654','2026-11-24 18:36:37.188655','2026-12-24 18:36:37.188367');
INSERT INTO "sitzung" VALUES('05692ca7e11145c7ab45c47067fa90ad','45d21030b30a47ee86ad4aca68431984','ec69b4e5ba70f85aea5ab05aff93a9de877352dd53cf3a791b2d74fadcbf9ea1',1,'iPhone (Bestand)','','geraet','','','2026-11-24 18:36:37.226312','2026-11-24 18:36:37.226314','2036-11-21 18:36:37.225783');
INSERT INTO "sitzung" VALUES('1817eef179364191a3f7b34d62a8300a','460f83c8cb6445b48305798306d0a892','e082d82049aff4bd253f2ada48db5361bb5c213cb70cf4802df234bdd805e9cf',1,'testclient','','browser','','','2026-11-24 18:36:37.266138','2026-11-24 18:36:37.266139','2026-12-24 18:36:37.265861');
INSERT INTO "sitzung" VALUES('09f8f66cc2644bd38c9ab1ac0e74d3c7','d08cae399db04601aa682ea2ea9f7c1a','d07e23f0d06cd3c3e2ac0aae8c6e8b4840dedf92dcbdca7a8641d9610973327d',1,'testclient','','browser','','','2026-11-24 18:36:37.578781','2026-11-24 18:36:37.578783','2026-12-24 18:36:37.578156');
INSERT INTO "sitzung" VALUES('4a87a32c45554423985390833117bc72','0bd719f4c4dc4a0dbc0364dc77d62aab','0a8f74c16ad079bd2052299be422f217db22b9542e0d094098cde5daeea1d623',1,'testclient','','browser','','','2026-11-24 18:36:37.686069','2026-11-24 18:36:37.686071','2026-12-24 18:36:37.685814');
CREATE TABLE termin (
	id INTEGER NOT NULL, 
	kalender_id VARCHAR(32) NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	uid VARCHAR(500) NOT NULL, 
	href TEXT NOT NULL, 
	etag VARCHAR(255) NOT NULL, 
	roh TEXT NOT NULL, 
	titel TEXT NOT NULL, 
	beschreibung TEXT NOT NULL, 
	ort TEXT NOT NULL, 
	beginn DATETIME NOT NULL, 
	ende DATETIME NOT NULL, 
	ganztaegig BOOLEAN NOT NULL, 
	zeitzone VARCHAR(64) NOT NULL, 
	rrule TEXT NOT NULL, 
	exdate TEXT NOT NULL, 
	recurrence_id VARCHAR(64) NOT NULL, 
	sequenz INTEGER NOT NULL, 
	erinnerung INTEGER NOT NULL, 
	organisator TEXT NOT NULL, 
	teilnehmer TEXT NOT NULL, 
	eingeladen_am DATETIME, 
	fremde_antworten TEXT NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	schmutzig BOOLEAN NOT NULL, 
	aus_einladung BOOLEAN NOT NULL, 
	angelegt DATETIME NOT NULL, 
	geaendert DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_termin_uid UNIQUE (kalender_id, uid, recurrence_id), 
	FOREIGN KEY(kalender_id) REFERENCES kalender (id) ON DELETE CASCADE
);
CREATE TABLE terminantwort (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	uid VARCHAR(500) NOT NULL, 
	antwort VARCHAR(16) NOT NULL, 
	gesendet DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_terminantwort_uid UNIQUE (benutzer_id, uid)
);
CREATE TABLE textvorlage (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	inhalt_html TEXT NOT NULL, 
	reihenfolge INTEGER NOT NULL, 
	angelegt DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE wiederherstellungscode (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	code_hash VARCHAR(64) NOT NULL, 
	verbraucht DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(benutzer_id) REFERENCES benutzer (id) ON DELETE CASCADE
);
INSERT INTO "wiederherstellungscode" VALUES(1,'f6c001bcad3945e7b1285cf800188d07','63fdb55c3aac34c6f090433eb9dd5d309c39e2739bec3ee8206027d44e07cfa6',NULL);
INSERT INTO "wiederherstellungscode" VALUES(2,'f6c001bcad3945e7b1285cf800188d07','9b84df8f661a8697b0c5142dc1879373961d8e42dcc72a4824a57f973e19f715',NULL);
INSERT INTO "wiederherstellungscode" VALUES(3,'f6c001bcad3945e7b1285cf800188d07','c66b3eb0e92f888729bfb2a050e258e624f38d036074f3470b3628d7c4986ad5',NULL);
INSERT INTO "wiederherstellungscode" VALUES(4,'f6c001bcad3945e7b1285cf800188d07','41a76f892a24b8c90e956570e8cbfd670bf37429aaa1d7a8c9623c3de374970b',NULL);
INSERT INTO "wiederherstellungscode" VALUES(5,'f6c001bcad3945e7b1285cf800188d07','9a3ea9906fef8cf64652385e7d61f48daa48d721823a6dfbfc9bb5b18b97350a',NULL);
INSERT INTO "wiederherstellungscode" VALUES(6,'f6c001bcad3945e7b1285cf800188d07','5b0112d3e42b23be3bbab20d3b2f5781e3e6ddf09a9198ff7dbef489d145fc70',NULL);
INSERT INTO "wiederherstellungscode" VALUES(7,'f6c001bcad3945e7b1285cf800188d07','e78e2a97a9fc067e1b7be5f21be7fb38f1d05a24972c6fbda12d8631ba7863bd',NULL);
INSERT INTO "wiederherstellungscode" VALUES(8,'f6c001bcad3945e7b1285cf800188d07','bcf6568de9a79998da8e8fdc420e8798893c921c0d199aac3568b6f56edfe3fa',NULL);
INSERT INTO "wiederherstellungscode" VALUES(9,'f6c001bcad3945e7b1285cf800188d07','06bdf7ad0238b1b4d1e19b30b00c6f3c439c475f9d164c0b5daa30715c83b0da',NULL);
INSERT INTO "wiederherstellungscode" VALUES(10,'f6c001bcad3945e7b1285cf800188d07','4c7cfd079c5ac678b2a5a36211f73fe9a05e294a9e49c6cd204681f6397ccb5c',NULL);
INSERT INTO "wiederherstellungscode" VALUES(11,'45d21030b30a47ee86ad4aca68431984','821a30f7af768e0bf724c0d875b52de22d8179cd3cb3f8f98b5959d5a27e0496',NULL);
INSERT INTO "wiederherstellungscode" VALUES(12,'45d21030b30a47ee86ad4aca68431984','8a64b10c86198c34919525212737819bbdadb44697406182475ca216ea7c292d',NULL);
INSERT INTO "wiederherstellungscode" VALUES(13,'45d21030b30a47ee86ad4aca68431984','75329ed0659031bf30fc36ed693cc3619eed4fd7be3801a3b62563391cf10555',NULL);
INSERT INTO "wiederherstellungscode" VALUES(14,'45d21030b30a47ee86ad4aca68431984','0f01867709ce52e83f4cb4f06b7bcbc5bcecf6e8e10bdf83a2791e3df4c6c2a1',NULL);
INSERT INTO "wiederherstellungscode" VALUES(15,'45d21030b30a47ee86ad4aca68431984','fcaa764cf617873fa9aa5676d8ba51dd670bdb6a457672a2a79ce38b91a6c9ea',NULL);
INSERT INTO "wiederherstellungscode" VALUES(16,'45d21030b30a47ee86ad4aca68431984','9f50b3067dee39c401caf852a43466ffa2329ed59ebe69ee6fe0a08b1df9138b',NULL);
INSERT INTO "wiederherstellungscode" VALUES(17,'45d21030b30a47ee86ad4aca68431984','8946ea0eb5afc47b7e05464df7d744f0a6c938cefb61283fa1a15cbf2380b306',NULL);
INSERT INTO "wiederherstellungscode" VALUES(18,'45d21030b30a47ee86ad4aca68431984','9697bceb39fc5b3ce360ee25fd5c654eeea49d9d46f5fc230d5d1908d3d49a95',NULL);
INSERT INTO "wiederherstellungscode" VALUES(19,'45d21030b30a47ee86ad4aca68431984','74172127cf9348090354f90f5dfa74bfdbfa963c7f7421591445f97c5b66ad54',NULL);
INSERT INTO "wiederherstellungscode" VALUES(20,'45d21030b30a47ee86ad4aca68431984','029cc056620823cc0cbe5559128ce77c5f2d2c7fdc3862b32f98efb28a21802c',NULL);
CREATE TABLE wiedervorlage (
	id INTEGER NOT NULL, 
	benutzer_id VARCHAR(32) NOT NULL, 
	konto_id VARCHAR(32) NOT NULL, 
	message_id VARCHAR(500) NOT NULL, 
	aufwachen DATETIME NOT NULL, 
	zurueck_pfad VARCHAR(512) NOT NULL, 
	betreff_abzug TEXT NOT NULL, 
	fehlversuche INTEGER NOT NULL, 
	naechster_versuch DATETIME, 
	angelegt DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_wiedervorlage_mail UNIQUE (benutzer_id, konto_id, message_id)
);
CREATE UNIQUE INDEX ix_benutzer_nummer ON benutzer (nummer);
CREATE UNIQUE INDEX ix_benutzer_benutzername ON benutzer (benutzername);
CREATE INDEX ix_aenderung_ziel ON aenderung (art, kennung);
CREATE INDEX ix_aenderung_lauf ON aenderung (benutzer_id, seq);
CREATE INDEX ix_kontaktgruppe_benutzer_id ON kontaktgruppe (benutzer_id);
CREATE INDEX ix_kontaktgruppe_mitglied_kontakt_id ON kontaktgruppe_mitglied (kontakt_id);
CREATE INDEX ix_kontaktgruppe_mitglied_benutzer_id ON kontaktgruppe_mitglied (benutzer_id);
CREATE INDEX ix_kontaktgruppe_mitglied_gruppe_id ON kontaktgruppe_mitglied (gruppe_id);
CREATE INDEX ix_regel_benutzer_id ON regel (benutzer_id);
CREATE INDEX ix_regel_reihenfolge ON regel (benutzer_id, reihenfolge);
CREATE INDEX ix_signatur_benutzer_id ON signatur (benutzer_id);
CREATE INDEX ix_signatur_konto_id ON signatur (konto_id);
CREATE INDEX ix_textvorlage_benutzer_id ON textvorlage (benutzer_id);
CREATE UNIQUE INDEX ix_einladung_schluessel_hash ON einladung (schluessel_hash);
CREATE INDEX ix_aufgabe_message_id ON aufgabe (message_id);
CREATE INDEX ix_aufgabe_benutzer_id ON aufgabe (benutzer_id);
CREATE INDEX ix_wiedervorlage_message_id ON wiedervorlage (message_id);
CREATE INDEX ix_wiedervorlage_konto_id ON wiedervorlage (konto_id);
CREATE INDEX ix_wiedervorlage_benutzer_id ON wiedervorlage (benutzer_id);
CREATE INDEX ix_schlagwort_benutzer_id ON schlagwort (benutzer_id);
CREATE UNIQUE INDEX ix_oidc_anbieter_kuerzel ON oidc_anbieter (kuerzel);
CREATE UNIQUE INDEX ix_oidc_anbieter_nummer ON oidc_anbieter (nummer);
CREATE INDEX ix_bildfreigabe_benutzer_id ON bildfreigabe (benutzer_id);
CREATE INDEX ix_terminantwort_benutzer_id ON terminantwort (benutzer_id);
CREATE UNIQUE INDEX ix_oauth_anbieter_art ON oauth_anbieter (art);
CREATE UNIQUE INDEX ix_ruecksetzung_schluessel_hash ON ruecksetzung (schluessel_hash);
CREATE INDEX ix_ruecksetzung_benutzer_id ON ruecksetzung (benutzer_id);
CREATE INDEX ix_wiederherstellungscode_benutzer_id ON wiederherstellungscode (benutzer_id);
CREATE INDEX ix_wiederherstellungscode_code_hash ON wiederherstellungscode (code_hash);
CREATE UNIQUE INDEX ix_sitzung_token_hash ON sitzung (token_hash);
CREATE INDEX ix_sitzung_benutzer_id ON sitzung (benutzer_id);
CREATE INDEX ix_app_kopplung_code_hash ON app_kopplung (code_hash);
CREATE INDEX ix_app_kopplung_benutzer_id ON app_kopplung (benutzer_id);
CREATE INDEX ix_oidc_verknuepfung_benutzer_id ON oidc_verknuepfung (benutzer_id);
CREATE UNIQUE INDEX uq_oidc_anbieter_subject ON oidc_verknuepfung (anbieter_id, subject);
CREATE INDEX ix_oidc_verknuepfung_issuer ON oidc_verknuepfung (issuer);
CREATE UNIQUE INDEX uq_oidc_anbieter_konto ON oidc_verknuepfung (anbieter_id, benutzer_id);
CREATE INDEX ix_aufgabenverbindung_benutzer_id ON aufgabenverbindung (benutzer_id);
CREATE INDEX ix_mail_termin_benutzer_id ON mail_termin (benutzer_id);
CREATE INDEX ix_mail_termin_mail ON mail_termin (benutzer_id, message_id);
CREATE INDEX ix_ki_vorgang_zeitpunkt ON ki_vorgang (zeitpunkt);
CREATE INDEX ix_ki_vorgang_benutzer_id ON ki_vorgang (benutzer_id);
CREATE INDEX ix_push_anmeldung_benutzer_id ON push_anmeldung (benutzer_id);
CREATE INDEX ix_oauth_zugang_benutzer_id ON oauth_zugang (benutzer_id);
CREATE INDEX ix_api_schluessel_benutzer_id ON api_schluessel (benutzer_id);
CREATE UNIQUE INDEX ix_api_schluessel_schluessel_hash ON api_schluessel (schluessel_hash);
CREATE INDEX ix_konto_benutzer_id ON konto (benutzer_id);
CREATE INDEX ix_adressbuch_benutzer_id ON adressbuch (benutzer_id);
CREATE INDEX ix_kalender_benutzer_id ON kalender (benutzer_id);
CREATE INDEX ix_ordner_konto_id ON ordner (konto_id);
CREATE INDEX ix_ausgang_konto_id ON ausgang (konto_id);
CREATE INDEX ix_ausgang_stand ON ausgang (stand);
CREATE INDEX ix_ausgang_benutzer_id ON ausgang (benutzer_id);
CREATE INDEX ix_kontakt_uid ON kontakt (uid);
CREATE INDEX ix_kontakt_name ON kontakt (benutzer_id, name);
CREATE UNIQUE INDEX uq_kontakt_adresse ON kontakt (benutzer_id, adresse) WHERE adresse <> '';
CREATE INDEX ix_kontakt_benutzer_id ON kontakt (benutzer_id);
CREATE INDEX ix_kontakt_adressbuch_id ON kontakt (adressbuch_id);
CREATE INDEX ix_abwesenheitsantwort_konto_id ON abwesenheitsantwort (konto_id);
CREATE INDEX ix_termin_kalender_id ON termin (kalender_id);
CREATE INDEX ix_termin_benutzer_id ON termin (benutzer_id);
CREATE INDEX ix_termin_fenster ON termin (kalender_id, beginn);
CREATE INDEX ix_nachricht_ordner_id ON nachricht (ordner_id);
CREATE INDEX ix_nachricht_thread_key ON nachricht (thread_key);
CREATE INDEX ix_nachricht_ungelesen ON nachricht (ordner_id) WHERE gelesen = 0;
CREATE INDEX ix_nachricht_message_id ON nachricht (benutzer_id, message_id);
CREATE INDEX ix_nachricht_betreff ON nachricht (konto_id, betreff_kern, datum);
CREATE INDEX ix_nachricht_konto_id ON nachricht (konto_id);
CREATE INDEX ix_nachricht_betreff_kern ON nachricht (betreff_kern);
CREATE INDEX ix_nachricht_zaehlen ON nachricht (konto_id, ordner_id, gelesen);
CREATE INDEX ix_nachricht_zeitachse ON nachricht (benutzer_id, datum);
CREATE INDEX ix_nachricht_benutzer_id ON nachricht (benutzer_id);
CREATE INDEX ix_nachricht_von_adresse ON nachricht (von_adresse);
CREATE INDEX ix_nachricht_liste ON nachricht (ordner_id, datum);
CREATE INDEX ix_nachricht_strang ON nachricht (benutzer_id, thread_key);
CREATE INDEX ix_erinnerungszustellung_termin_id ON erinnerungszustellung (termin_id);
CREATE INDEX ix_erinnerungszustellung_benutzer_id ON erinnerungszustellung (benutzer_id);
CREATE INDEX ix_anhang_nachricht_id ON anhang (nachricht_id);
CREATE INDEX ix_anhang_blob_hash ON anhang (blob_hash);
CREATE TRIGGER aenderung_nachricht_neu AFTER INSERT ON nachricht BEGIN
        
        DELETE FROM aenderung WHERE art = 'nachricht' AND kennung = NEW.id;
        INSERT INTO aenderung (benutzer_id, art, kennung, konto_id, weg, zeit)
        VALUES (NEW.benutzer_id, 'nachricht', NEW.id, NEW.konto_id, 0, CAST(strftime('%s', 'now') AS INTEGER));
    
    END;
CREATE TRIGGER aenderung_nachricht_aend
    AFTER UPDATE OF gelesen, markiert, beantwortet, schlagworte, ordner_id, uid, wichtigkeit ON nachricht
    WHEN NEW.gelesen IS NOT OLD.gelesen OR NEW.markiert IS NOT OLD.markiert OR NEW.beantwortet IS NOT OLD.beantwortet OR NEW.schlagworte IS NOT OLD.schlagworte OR NEW.ordner_id IS NOT OLD.ordner_id OR NEW.uid IS NOT OLD.uid OR NEW.wichtigkeit IS NOT OLD.wichtigkeit BEGIN
        
        DELETE FROM aenderung WHERE art = 'nachricht' AND kennung = NEW.id;
        INSERT INTO aenderung (benutzer_id, art, kennung, konto_id, weg, zeit)
        VALUES (NEW.benutzer_id, 'nachricht', NEW.id, NEW.konto_id, 0, CAST(strftime('%s', 'now') AS INTEGER));
    
    END;
CREATE TRIGGER aenderung_nachricht_weg AFTER DELETE ON nachricht BEGIN
        
        DELETE FROM aenderung WHERE art = 'nachricht' AND kennung = OLD.id;
        INSERT INTO aenderung (benutzer_id, art, kennung, konto_id, weg, zeit)
        VALUES (OLD.benutzer_id, 'nachricht', OLD.id, OLD.konto_id, 1, CAST(strftime('%s', 'now') AS INTEGER));
    
    END;
CREATE TRIGGER aenderung_ordner_neu AFTER INSERT ON ordner BEGIN
        
        DELETE FROM aenderung WHERE art = 'ordner' AND kennung = NEW.id;
        INSERT INTO aenderung (benutzer_id, art, kennung, konto_id, weg, zeit)
        SELECT k.benutzer_id, 'ordner', NEW.id, NEW.konto_id, 0, CAST(strftime('%s', 'now') AS INTEGER)
        FROM konto k WHERE k.id = NEW.konto_id;
    
    END;
CREATE TRIGGER aenderung_ordner_aend
    AFTER UPDATE OF pfad, name, rolle, waehlbar, abonniert ON ordner
    WHEN NEW.pfad IS NOT OLD.pfad OR NEW.name IS NOT OLD.name OR NEW.rolle IS NOT OLD.rolle OR NEW.waehlbar IS NOT OLD.waehlbar OR NEW.abonniert IS NOT OLD.abonniert BEGIN
        
        DELETE FROM aenderung WHERE art = 'ordner' AND kennung = NEW.id;
        INSERT INTO aenderung (benutzer_id, art, kennung, konto_id, weg, zeit)
        SELECT k.benutzer_id, 'ordner', NEW.id, NEW.konto_id, 0, CAST(strftime('%s', 'now') AS INTEGER)
        FROM konto k WHERE k.id = NEW.konto_id;
    
    END;
CREATE TRIGGER aenderung_ordner_weg AFTER DELETE ON ordner BEGIN
        
        DELETE FROM aenderung WHERE art = 'ordner' AND kennung = OLD.id;
        INSERT INTO aenderung (benutzer_id, art, kennung, konto_id, weg, zeit)
        SELECT k.benutzer_id, 'ordner', OLD.id, OLD.konto_id, 1, CAST(strftime('%s', 'now') AS INTEGER)
        FROM konto k WHERE k.id = OLD.konto_id;
    
    END;
CREATE TRIGGER aenderung_postfach_neu AFTER INSERT ON konto BEGIN
        
        DELETE FROM aenderung WHERE art = 'postfach' AND kennung = NEW.id;
        INSERT INTO aenderung (benutzer_id, art, kennung, konto_id, weg, zeit)
        VALUES (NEW.benutzer_id, 'postfach', NEW.id, NEW.id, 0, CAST(strftime('%s', 'now') AS INTEGER));
    
    END;
CREATE TRIGGER aenderung_postfach_aend
    AFTER UPDATE OF anzeigename, adresse, farbe, aktiv, tags, stoerung ON konto
    WHEN NEW.anzeigename IS NOT OLD.anzeigename OR NEW.adresse IS NOT OLD.adresse OR NEW.farbe IS NOT OLD.farbe OR NEW.aktiv IS NOT OLD.aktiv OR NEW.tags IS NOT OLD.tags OR NEW.stoerung IS NOT OLD.stoerung BEGIN
        
        DELETE FROM aenderung WHERE art = 'postfach' AND kennung = NEW.id;
        INSERT INTO aenderung (benutzer_id, art, kennung, konto_id, weg, zeit)
        VALUES (NEW.benutzer_id, 'postfach', NEW.id, NEW.id, 0, CAST(strftime('%s', 'now') AS INTEGER));
    
    END;
CREATE TRIGGER aenderung_postfach_weg AFTER DELETE ON konto BEGIN
        
        DELETE FROM aenderung WHERE art = 'postfach' AND kennung = OLD.id;
        INSERT INTO aenderung (benutzer_id, art, kennung, konto_id, weg, zeit)
        VALUES (OLD.benutzer_id, 'postfach', OLD.id, OLD.id, 1, CAST(strftime('%s', 'now') AS INTEGER));
    
    END;
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('aenderung',2);
COMMIT;
